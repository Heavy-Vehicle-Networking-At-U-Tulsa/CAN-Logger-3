var searchData=
[
  ['pos_5ft',['pos_t',['../ios_8h.html#aae8adaedc486a4b2f67576fdeaf0a585',1,'ios.h']]],
  ['pos_5ftype',['pos_type',['../classios__base.html#abe85cf1f181b8bce8022f05ab76aae7f',1,'ios_base']]]
];
