var searchData=
[
  ['minimumserial',['MinimumSerial',['../class_minimum_serial.html',1,'']]]
];
