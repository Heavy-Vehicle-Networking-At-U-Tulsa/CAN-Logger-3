var searchData=
[
  ['datalength',['dataLength',['../class_ex_fat_file.html#ada4dde9f2eed36bf556fcf1bd3d28ccf',1,'ExFatFile']]],
  ['datastartsector',['dataStartSector',['../class_fs_volume.html#a93d1607c50ace4d50088c8619a4fa78d',1,'FsVolume::dataStartSector()'],['../class_fat_partition.html#a31f50a4d995e9c97e2be0ff8ff4ad1af',1,'FatPartition::dataStartSector()']]],
  ['dbgfat',['dbgFat',['../class_fat_partition.html#a0af1e91a311180119b4a2c85d7e6e87e',1,'FatPartition']]],
  ['deactivate',['deactivate',['../class_sd_spi_lib_driver.html#a120d6b78f9dad6837d10b45b76d32c82',1,'SdSpiLibDriver::deactivate()'],['../class_sd_spi_alt_driver.html#ae6ce25d124e31a8762375ae548a92818',1,'SdSpiAltDriver::deactivate()']]],
  ['dec',['dec',['../ios_8h.html#ada38ab90e22f0ebb638cb864a35c562d',1,'ios.h']]],
  ['direntry',['dirEntry',['../class_fat_file.html#a6858d18c807411a071fd6d1b39d50087',1,'FatFile']]],
  ['dirty',['dirty',['../class_fs_cache.html#af50f564561a2db190280769d4641147b',1,'FsCache::dirty()'],['../class_fat_cache.html#ab4d3b0c16bb6a116c7d01afff2dcb307',1,'FatCache::dirty()']]],
  ['dmpfile',['dmpFile',['../class_fat_file.html#a4f01d27954ae49aeb6888ac7302f55d9',1,'FatFile']]]
];
